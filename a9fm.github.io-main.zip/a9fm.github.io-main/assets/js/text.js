$(function () {
    $(".typed").typed({
        strings: ["Крым ничей", "#НетВойне", "ANTI-SCAMMMER", "Python Developer", "coder", "vzlom jopi", "hmmm...", "bruh", "Hack system...", "h@Cк3D!"],
        typeSpeed: 30,
        backSpeed: 0,
        cursorChar: ['❚'],
        smartBackspace: true,
        fadeOut: true,
        loop: true,
    });
});
